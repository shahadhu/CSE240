#include "Student.h"
#include "Container.h"
#include "Undergraduate.h"
#include "Graduate.h"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// forward declarations
void flush();
void branching(char);
void helper(char);
int add(string f, string l, int grade, int edu);
double classAverage();
Student* search(string f, string l);
void delete_one(string f, string l);
void delete_all();
void print_all();
void save(string fileName);
void load(string fileName);

Container* list = NULL; // global list

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF); // Use to check for memory leaks in VS

	load("Students.txt");

	char ch = 'i';

	do {
		cout << "Please enter your selection\n";
		cout << "\ta: add a student\n";
		cout << "\tc: change a student's grade\n";
		cout << "\tv: display class average\n";
		cout << "\td: delete a student\n";
		cout << "\tp: print students\n";
		cout << "\tq: quit\n";
		cin >> ch;
		flush();
		branching(ch);
	} while (ch != 'q');

	save("Students.txt");
	delete_all();

	return 0;
}

void flush()
{
	int c;
	do c = getchar(); while (c != '\n' && c != EOF);
}

void branching(char c)
{
	switch (c) {
	case 'a':
	case 'c':
	case 'v':
	case 'd':
	case 'p':
		helper(c);
		break;
	case 'q':
		break;
	default:
		printf("\nInvalid input!\n\n");
	}
}

void helper(char c)
{
	string f;
	string l;

	if (c == 'p') // print all students
	{
		print_all();
		return;
	}
	else if (c == 'v') // display class average
	{
		double result = classAverage();
		if (result >= 0)
			cout << endl << "Class Average: " << classAverage() << endl << endl;
		return;
	}

	cout << endl << "Please enter the student's first name: " << endl;
	cin >> f;
	cout << "Please enter the student's last name: " << endl;
	cin >> l; flush();

	Student* s = NULL;
	s = search(f, l);

	if (c == 'a') // add student
	{
		int edu = -1;
		int grade;

		cout << "Please enter the student's grade: " << endl;
		cin >> grade;

		while (!(edu == 1 || edu == 2))
		{
			cout << "Please select one of the following: " << endl;
			cout << "1. Undergraduate " << endl;
			cout << "2. Graduate" << endl;
			cin >> edu;
		}

		int result = add(f, l, grade, edu);

		if (result == 0)
			cout << endl << "Student already on the list." << endl << endl;
		else if (result == 1)
			cout << endl << "Student added." << endl << endl;
	}
	else if (c == 'c') // change student's grade
	{
		if (s == NULL)
		{
			cout << endl << "Student not found." << endl << endl;
			return;
		}

		int newGrade;

		cout << "Please enter the student's new grade: " << endl;
		cin >> newGrade; flush();

		changeGrade(s, newGrade);

		cout << endl << "Student's grade changed." << endl << endl;
	}
	else if (c == 'd') // delete student
	{
		if (s == NULL)
		{
			cout << endl << "Student not found." << endl << endl;
			return;
		}

		delete_one(f, l);
		cout << endl << "Student deleted." << endl << endl;
	}
}

void changeGrade(Student* s, int g){
	s->grade = g;
}

int add(string f, string l, int grade, int edu)
{
	Container* c = new Container();

	if (edu == 1)
	{
		Undergraduate* u = new Undergraduate(f, l, grade, edu);
		c->student = u;
	}
	else
	{
		Graduate* g = new Graduate(f, l, grade, edu);
		c->student = g;
	}

	c->next = NULL;

	if (list == NULL)
	{
		list = c;
		return 1;
	}
	else if (list->student->getFirstName() == f && list->student->getLastName() == l)
	{
		delete c->student;
		delete c;
		return 0;
	}

	Container* follower = list;
	Container* traverser = list->next;

	while (traverser != NULL) {
		if (traverser->student->getFirstName() == f && traverser->student->getLastName() == l)
		{
			delete c->student;
			delete c;
			return 0;
		}
		follower = traverser;
		traverser = traverser->next;
	}

	follower->next = c;
	return 1;
}

double classAverage()
{
	double result = 0; double count = 0;
	Container* traverser = list;

	while (traverser != NULL)
	{
		result += traverser->student->getGrade();
		traverser = traverser->next;
		count++;
	}

	try{
		if (count == 0)
			throw "List is empty!";
		else
			result = result / count;
	}
	catch (char* ex)
	{
		cout << endl << ex << endl << endl;
		return -1;
	}

	return result;
}

Student* search(string f, string l)
{
	Container *traverser = list;

	while (traverser != NULL)
	{
		if (traverser->student->getFirstName() == f && traverser->student->getLastName() == l)
			return traverser->student;
		traverser = traverser->next;
	}
	return NULL;
}

void delete_one(string f, string l)
{
	Container *follow = list;
	Container *c = list->next;
	Container *temp;

	if (list->student->getFirstName() == f && list->student->getLastName() == l)
	{
		temp = list;
		list = list->next;
		delete temp->student;
		delete temp;
		return;
	}

	while (c != NULL)
	{
		if (c->student->getFirstName() == f && c->student->getLastName() == l)
		{
			temp = c;
			c = c->next;
			follow->next = c;
			delete temp->student;
			delete temp;
			return;
		}
		follow = c;
		c = c->next;
	}
}

void delete_all()
{
	while (list != NULL)
	{
		Container* c = list;
		list = list->next;
		delete c->student;
		delete c;
	}
}

void print_all()
{
	Container *traverser = list;

	if (list == NULL)
		cout << endl << "List is empty!" << endl << endl;

	while (traverser != NULL)
	{
		traverser->student->displayInfo();
		traverser = traverser->next;
	}
}

void save(string fileName)
{
	int count = 0;
	Container* traverser = list;

	while (traverser != NULL) // count number of Containers in linked list
	{
		traverser = traverser->next;
		count++;
	}

	ofstream myfile;
	myfile.open(fileName);

	if (myfile.is_open()){
		traverser = list;
		myfile << count;

		while (traverser != NULL)
		{
			myfile << traverser->student->getFirstName() << endl;
			myfile << traverser->student->getLastName() << endl;
			myfile << traverser->student->getGrade() << endl;
			myfile << traverser->student->getEdu() << endl;
			traverser = traverser->next;
		}
		myfile.close();
	}
}

void load(string fileName)
{
	int count = 0;
	Container* traverser = list;

	ifstream myfile;
	myfile.open(fileName);

	if (myfile.is_open()){
		myfile >> count;
		string f, l;
		int g;
		int e;

		for (int i = 0; i < count; i++)
		{
			Container* newNode = new Container();

			myfile >> f;
			myfile >> l;
			myfile >> g;
			myfile >> e;

			if (e == 1)
				newNode->student = new Undergraduate(f, l, g, e);
			else
				newNode->student = new Graduate(f, l, g, e);

			newNode->next = NULL;

			if (list == NULL)
			{
				newNode->next = list;
				list = newNode;
			}
			else
			{
				traverser = list;
				while (traverser->next != NULL) // traverse to the end of the list
					traverser = traverser->next;
				traverser->next = newNode;
			}
		}
		myfile.close();
	}
}