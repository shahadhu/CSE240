#include "Student.h"

Student::Student(string f, string l, int g, int e) {
	fname = f;
	lname = l;
	grade = g;
	edu = e;
}

string Student::getFirstName() {
	return fname;
}

string Student::getLastName() {
	return lname;
}

int Student::getGrade() {
	return grade;
}

int Student::getEdu() {
	return edu;
}