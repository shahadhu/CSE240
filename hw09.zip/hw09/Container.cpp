#include "Container.h"

// Constructor for Container class
Container::Container(){
	student = NULL;
	next = NULL;
}