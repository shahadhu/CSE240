#include "Student.h"
#include "Undergraduate.h"

#include <iostream>

void Undergraduate::displayInfo()
{
	cout << endl << "Name: " << getFirstName() << " " << getLastName() << endl;
	cout << "Grade:" << getGrade() << endl;
	cout << "Education Level: Undergraduate" << endl << endl;
}