#ifndef _GRADUATE_H_
#define _GRADUATE_H_

#include "Student.h"

class Graduate : public Student {
public:
	Graduate(string f, string l, int grade, int edu) : Student(f, l, grade, edu){}

	void displayInfo();
};

#endif // _GRADUATE_H_