#ifndef _UNDERGRAD_H_
#define _UNDERGRAD_H_

#include "Student.h"

class Undergraduate : public Student {
public:
	Undergraduate(string f, string l, int grade, int edu) : Student(f, l, grade, edu){}

	void displayInfo();
};

#endif // _UNDERGRAD_H_