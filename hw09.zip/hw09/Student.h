#ifndef _STUDENT_H_
#define _STUDENT_H_

#include <string>
using namespace std;

class Student {
private:
	// private local variables
	string fname, lname;
	int grade;
	int edu;

public:
	Student(string f, string l, int grade, int edu); // constructor
	string getFirstName(); // accessor
	string getLastName(); // accessor
	int getGrade(); // accessor
	int getEdu(); // accessor

	friend void changeGrade(Student* s, int g);

	virtual void displayInfo(){ }
};

#endif // _STUDENT_H_