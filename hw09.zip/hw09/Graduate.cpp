#include "Student.h"
#include "Graduate.h"

#include <iostream>

void Graduate::displayInfo()
{
	cout << endl << "Name: " << getFirstName() << " " << getLastName() << endl;
	cout << "Grade:" << getGrade() << endl;
	cout << "Education Level: Graduate" << endl << endl;
}